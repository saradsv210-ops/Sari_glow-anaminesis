# Sari Glow — Ficha de Anamnesis

## Cómo publicarlo (sin usar la terminal)

### 1. Subir esta carpeta a GitHub
1. Entrá a github.com y creá una cuenta gratis (si no tenés)
2. "New repository" → nombre, por ejemplo `sari-glow-app` → Create repository
3. En la página del repo, click en "uploading an existing file" (o "Add file" → "Upload files")
4. Arrastrá **todo el contenido de esta carpeta** (no la carpeta en sí, sino lo que tiene adentro: `index.html`, `netlify.toml`, `package.json`, la carpeta `netlify/`)
5. "Commit changes"

### 2. Conectar con Netlify
1. Entrá a app.netlify.com → "Add new project" → "Import an existing project"
2. Elegí GitHub y autorizá el acceso → seleccioná el repositorio `sari-glow-app`
3. Dejá la configuración que detecta automáticamente (publish directory `.`, functions `netlify/functions`) → "Deploy"
4. Esperá 1-2 minutos a que termine el deploy

### 3. Configurar la contraseña del panel admin
1. En el sitio dentro de Netlify: "Site configuration" → "Environment variables"
2. "Add a variable" → Key: `ADMIN_PASSWORD` → Value: `251510` (o la que prefieras)
3. Guardar, y volver a "Deploys" → "Trigger deploy" → "Deploy site" (para que tome la variable nueva)

Listo — la app queda funcionando en la URL que te da Netlify (podés ponerle un dominio propio después desde "Domain settings").

## Cómo actualizar la app más adelante
Si querés cambiar algo del diseño o las preguntas, subime el archivo y te devuelvo uno nuevo — después solo tenés que volver a subirlo a GitHub (arrastrando el archivo nuevo sobre el repositorio, "Commit changes") y Netlify lo vuelve a publicar solo.

## Estructura del proyecto
- `index.html` — toda la app (formulario del paciente + panel admin)
- `netlify/functions/submit-ficha.js` — guarda cada ficha completada
- `netlify/functions/admin-data.js` — valida la contraseña y entrega los datos al panel admin
- `netlify.toml` — le dice a Netlify dónde están las funciones
- `package.json` — la única dependencia (`@netlify/blobs`, la base de datos)
