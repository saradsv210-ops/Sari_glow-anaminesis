// Guarda un paciente (upsert por DNI) y agrega una ficha a su historial.
// Se usa Netlify Blobs como base de datos: un "store" para pacientes y
// otro para fichas. No necesita ninguna credencial en el frontend —
// Netlify Blobs se autoconfigura automáticamente al correr en Netlify.
const { getStore } = require('@netlify/blobs');

function normDni(v){ return (v || '').toString().replace(/\D/g, ''); }

function jsonResponse(statusCode, body){
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Método no permitido.' });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return jsonResponse(400, { error: 'JSON inválido.' });
  }

  const { patient, ficha } = payload;
  if (!patient || !ficha || !patient.dni || !ficha.fichaId) {
    return jsonResponse(400, { error: 'Faltan datos del paciente o de la ficha.' });
  }

  const dni = normDni(patient.dni);
  if (!dni) {
    return jsonResponse(400, { error: 'DNI inválido.' });
  }

  try {
    const patients = getStore('patients');
    const existing = await patients.get(dni, { type: 'json' });

    const record = {
      dni,
      nombre: patient.nombre || (existing && existing.nombre) || '',
      fechaNacimiento: patient.fechaNacimiento || (existing && existing.fechaNacimiento) || '',
      telefono: patient.telefono || '',
      email: patient.email || '',
      domicilio: patient.domicilio || '',
      createdAt: (existing && existing.createdAt) || new Date().toISOString()
    };
    await patients.setJSON(dni, record);

    const fichas = getStore('fichas');
    const fichaKey = dni + '__' + ficha.fichaId;
    await fichas.setJSON(fichaKey, { ...ficha, patientDni: dni });

    return jsonResponse(200, { ok: true });
  } catch (e) {
    return jsonResponse(500, { error: 'Error del servidor al guardar: ' + e.message });
  }
};
