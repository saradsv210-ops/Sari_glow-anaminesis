// Devuelve todos los pacientes y sus fichas — solo si la contraseña es
// correcta. La contraseña real vive en Netlify (Site settings > Environment
// variables > ADMIN_PASSWORD), nunca en el código del sitio.
const { getStore } = require('@netlify/blobs');

function jsonResponse(statusCode, body){
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Método no permitido.' });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return jsonResponse(400, { error: 'JSON inválido.' });
  }

  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
  if (!ADMIN_PASSWORD) {
    return jsonResponse(500, {
      error: 'Falta configurar ADMIN_PASSWORD en Netlify (Site settings > Environment variables) y volver a deployar.'
    });
  }

  if ((payload.password || '') !== ADMIN_PASSWORD) {
    return jsonResponse(401, { error: 'Contraseña incorrecta.' });
  }

  try {
    const patientsStore = getStore('patients');
    const fichasStore = getStore('fichas');

    const patientList = await patientsStore.list();
    const fichaList = await fichasStore.list();

    const byDni = {};
    for (const item of patientList.blobs) {
      const p = await patientsStore.get(item.key, { type: 'json' });
      if (p) byDni[p.dni] = { ...p, fichas: [] };
    }
    for (const item of fichaList.blobs) {
      const f = await fichasStore.get(item.key, { type: 'json' });
      if (f && byDni[f.patientDni]) byDni[f.patientDni].fichas.push(f);
    }

    return jsonResponse(200, { patients: Object.values(byDni) });
  } catch (e) {
    return jsonResponse(500, { error: 'Error del servidor al leer los datos: ' + e.message });
  }
};
